namespace MGNZ.Squidex.Client.Tests.Stories
{
  public class KnownUserOAuthCreds
  {
    public string OAuthAppName { get; set; }
    public string OAuthClientId { get; set; }
    public string OAuthClientSecret { get; set; }
  }
}