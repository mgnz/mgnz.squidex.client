namespace MGNZ.Squidex.Client.Transport
{
  public class ClientPermissions
  {
    public const string Developer = "developer";
    public const string Editor = "editor";
    public const string Reader = "reader";
  }
}