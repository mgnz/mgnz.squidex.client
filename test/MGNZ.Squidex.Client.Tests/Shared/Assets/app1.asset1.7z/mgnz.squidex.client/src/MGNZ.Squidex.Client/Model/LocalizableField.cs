namespace MGNZ.Squidex.Client.Model
{
  using System.Collections.Generic;

  public class LocalizableField : Dictionary<string, string>
  {
  }
}